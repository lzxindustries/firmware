LZX INDUSTRIES MEMORY PALACE
STILL IMAGE LOADER INSTRUCTIONS

(1) Still images are loaded from /stills/ntsc when Memory Palace is in NTSC mode, and from /stills/pal when Memory Palace is in PAL mode.
(2) Images are organized in sets of up to 32 images.  Each set has its own subfolder, located at /stills/<format>/<set name> on the SD card.
(3) The native resolution for NTSC stills is 720x480.  For PAL stills, it is 720x576.  
(4) Supported formats include JPG, PNG, BMP and GIF. Image formats should be ARGB 8-bit, RGB 8-bit or Grayscale 8-bit.
(5) Thumbnails for each image should be created and stored in /stills/<format>/<set name>/thumb.
(6) Thumbnail images should have the exact file name/format as the source image and have a resolution of 128x96.

CREDITS
/nature images were downloaded from open source stock image archive at pexels.com by Lars Larsen
/ramps semicir, spacer, hexag and pentag were free images downloaded from geometrycode.com
other /ramps were designed in Adobe Photoshop by Lars Larsen & Dave Larsen 
/MX50 images were prepared by Jonas Bers